============================
 dinopy.input_opener module
============================

.. automodule:: dinopy.input_opener
    :members:
    :undoc-members:
