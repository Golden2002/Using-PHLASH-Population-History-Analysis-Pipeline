============================
 dinopy.fasta_reader module
============================

.. automodule:: dinopy.fasta_reader
    :members:
    :undoc-members:
