============================
 dinopy.fastq_reader module
============================

.. automodule:: dinopy.fastq_reader
    :members:
    :undoc-members:
