dinopy.shaping module
=====================

.. automodule:: dinopy.shaping
    :members:
    :undoc-members:
    :show-inheritance:
