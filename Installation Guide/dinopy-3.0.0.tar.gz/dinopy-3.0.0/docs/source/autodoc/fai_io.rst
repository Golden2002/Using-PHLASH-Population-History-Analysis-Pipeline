======================
 dinopy.fai_io module
======================

.. automodule:: dinopy.fai_io
    :members:
    :undoc-members:
