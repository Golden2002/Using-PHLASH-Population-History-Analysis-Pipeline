=======================
 dinopy.creader module
=======================

.. automodule:: dinopy.creader
    :members:
    :undoc-members:
