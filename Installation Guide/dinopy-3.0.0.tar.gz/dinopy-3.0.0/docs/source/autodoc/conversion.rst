==========================
 dinopy.conversion module
==========================

.. automodule:: dinopy.conversion
    :members:
    :undoc-members:
