dinopy.auxiliary module
-----------------------

.. automodule:: dinopy.auxiliary
    :members:
    :undoc-members:
