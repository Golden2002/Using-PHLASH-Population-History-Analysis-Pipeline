============================
 dinopy.fastq_writer module
============================

.. automodule:: dinopy.fastq_writer
    :members:
    :undoc-members:
