dinopy.nameline_parser module
-----------------------------

.. automodule:: dinopy.nameline_parser
    :members:
    :undoc-members:
