============================
 dinopy.fasta_writer module
============================

.. automodule:: dinopy.fasta_writer
    :members:
    :undoc-members:
